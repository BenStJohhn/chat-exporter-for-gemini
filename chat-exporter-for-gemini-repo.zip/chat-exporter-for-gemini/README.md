# Chat Exporter for Gemini

An unofficial Chrome extension that exports **all of your Google Gemini conversations to Markdown files**, one `.md` file per chat, plus an index linking them all.

Google Takeout doesn't give you your Gemini conversations in a usable form. This extension does: it walks your chat list, opens each conversation, loads its full history and saves it as clean Markdown you can keep, search, or drop into Obsidian, Notion or any notes app.

> **Not affiliated with, endorsed by, or sponsored by Google.** "Gemini" and "Google" are trademarks of Google LLC and are used here only to describe what this tool works with.

## Privacy

Everything happens inside your own browser tab.

- No servers, no analytics, no tracking, no network requests of any kind.
- Your conversations go from the Gemini page straight to your Downloads folder.
- It only runs on `gemini.google.com`, and the only permissions it asks for are `downloads` (to save files) and `storage` (to remember progress and settings).

The code is short and readable. Please check it yourself rather than taking this on trust. See [PRIVACY.md](PRIVACY.md).

## Install

The extension isn't on the Chrome Web Store, so you install it in developer mode. It takes about two minutes.

1. Download the latest `chat-exporter-for-gemini-vX.Y.Z.zip` from [Releases](../../releases) and unzip it (or clone this repo).
2. Open `chrome://extensions` and switch on **Developer mode** (top right).
3. Click **Load unpacked** and select the `extension` folder.
4. Recommended: in `chrome://settings/downloads`, turn **off** "Ask where to save each file before downloading", otherwise Chrome will prompt for every chat.

It should also work in other Chromium browsers (Edge, Brave, Arc), but it's only been tested in Chrome.

## Use

1. Open [gemini.google.com](https://gemini.google.com) and refresh the tab if it was already open. Make sure the left sidebar with your chat list is visible.
2. Click the extension icon, then **Export all chats**.
3. The extension scrolls the sidebar to find every chat, then opens each one, scrolls it to the top to load the full history, and saves it. A progress box in the bottom-right corner has a **Stop** button. Keep the tab in the foreground while it runs.
4. Files are saved to `Downloads/<folder name>/` as `0001 - <title>.md`, `0002 - …` (newest first), along with `_index.md`.

**Export this chat only** saves just the conversation you're viewing. If a run is stopped or the tab closes, **Resume** in the popup carries on from where it stopped.

Expect roughly 10–15 seconds per chat, so a few hundred chats can take an hour or more.

### Output format

```markdown
---
title: "Designing a gearbox mount"
url: https://gemini.google.com/app/1a2b3c...
conversation_id: 1a2b3c...
exported: 2026-10-13T09:00:00.000Z
turns: 12
---

# Designing a gearbox mount

## You

...

## Gemini

...
```

Headings, lists, tables, code blocks (with language), links, LaTeX maths and blockquotes are preserved.

**Not included:** Gemini's hidden "thinking" panels, alternative drafts, and images or files you uploaded (these appear as placeholders).

## Troubleshooting

| Problem | Fix |
| --- | --- |
| "No chats found in the sidebar" | Open the sidebar (☰ menu) so your chat list is visible, then try again. |
| "Refresh the Gemini tab…" | The extension loads when the page loads. Refresh Gemini after installing or updating. |
| Some files have the wrong or duplicated content | Tick **Reload page for every chat** in the popup. It's slower but loads each chat fresh. |
| Long chats are cut short | Increase **Pause between chats**, or open that chat and use **Export this chat only**. |
| It stopped working entirely | Google has probably changed Gemini's page layout. Please [open an issue](../../issues). |

## Limitations

This tool reads the Gemini web page as it appears in your browser, so it **can break whenever Google updates the site**. It doesn't use any private API and doesn't bypass any login or access control: it can only export what you can already see when signed in. Use it in line with Google's terms of service.

## Contributing

Issues and pull requests are welcome, especially fixes when Gemini's page structure changes. The page selectors live near the top of `extension/content.js`, and the HTML-to-Markdown conversion is in `extension/md.js`.

## Credits

Built by Ben St John with help from Claude (Anthropic).

## Licence

[MIT](LICENSE). Provided "as is", without warranty of any kind. Keep your own backups.
