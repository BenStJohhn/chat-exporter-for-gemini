// Runs on gemini.google.com. Walks the sidebar chat list, opens each chat,
// converts it to Markdown and hands it to the background worker to save.
// Progress lives in chrome.storage so a full page reload can resume the run.
(() => {
  if (window.__gxLoaded) return;
  window.__gxLoaded = true;

  const STATE_KEY = 'gx_state';
  const TURN_SEL = 'user-query, model-response';
  const ID_RE = /\/(?:app|gem\/[^/?#]+)\/([a-f0-9]{8,})/i;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let running = false;
  let scanning = false;

  const getState = async () => (await chrome.storage.local.get(STATE_KEY))[STATE_KEY] || null;
  const setState = (st) => chrome.storage.local.set({ [STATE_KEY]: st });

  async function waitFor(fn, timeout = 10000, interval = 250) {
    const end = Date.now() + timeout;
    while (Date.now() < end) {
      try { const v = fn(); if (v) return v; } catch (e) { /* ignore */ }
      await sleep(interval);
    }
    return null;
  }

  function waitQuiet(target, quietMs = 1000, maxMs = 12000) {
    return new Promise((resolve) => {
      let quiet;
      const done = () => { obs.disconnect(); clearTimeout(quiet); clearTimeout(cap); resolve(); };
      const obs = new MutationObserver(() => { clearTimeout(quiet); quiet = setTimeout(done, quietMs); });
      obs.observe(target, { subtree: true, childList: true, characterData: true });
      quiet = setTimeout(done, quietMs);
      const cap = setTimeout(done, maxMs);
    });
  }

  function scrollableAncestor(el) {
    for (let p = el && el.parentElement; p; p = p.parentElement) {
      const oy = getComputedStyle(p).overflowY;
      if ((oy === 'auto' || oy === 'scroll') && p.scrollHeight > p.clientHeight + 10) return p;
    }
    return null;
  }

  function safeName(s, max = 80) {
    return (s || '')
      .replace(/[\\/:*?"<>|~\u0000-\u001f]/g, ' ')
      .replace(/\s+/g, ' ').trim()
      .replace(/^\.+/, '')
      .slice(0, max).trim()
      .replace(/[. ]+$/, '') || 'Untitled';
  }

  const idFromPath = (p) => { const m = (p || '').match(ID_RE); return m ? m[1] : null; };

  // ---------------- Overlay ----------------
  function overlay(text, closable = false) {
    let box = document.getElementById('gx-overlay');
    if (!box) {
      box = document.createElement('div');
      box.id = 'gx-overlay';
      Object.assign(box.style, {
        position: 'fixed', right: '16px', bottom: '16px', zIndex: '2147483647',
        background: '#1f1f1f', color: '#fff', padding: '12px 14px', borderRadius: '10px',
        font: '13px/1.4 system-ui, sans-serif', maxWidth: '340px',
        boxShadow: '0 4px 16px rgba(0,0,0,.35)', display: 'flex', gap: '10px', alignItems: 'center'
      });
      const span = document.createElement('span');
      span.id = 'gx-text';
      span.style.flex = '1';
      const btn = document.createElement('button');
      btn.id = 'gx-btn';
      Object.assign(btn.style, {
        background: '#8ab4f8', color: '#000', border: '0', borderRadius: '6px',
        padding: '4px 10px', cursor: 'pointer', font: 'inherit'
      });
      box.append(span, btn);
      document.body.appendChild(box);
    }
    box.querySelector('#gx-text').textContent = text;
    const btn = box.querySelector('#gx-btn');
    btn.textContent = closable ? 'Close' : 'Stop';
    btn.onclick = closable ? () => box.remove() : () => stop();
  }

  // ---------------- Sidebar ----------------
  function convEntries() {
    const out = [];
    const seen = new Set();
    for (const el of document.querySelectorAll('a[href], [data-test-id="conversation"]')) {
      if (el.closest('message-content, user-query, model-response')) continue;
      let id = null, url = null;
      const href = el.getAttribute('href');
      if (href) {
        const m = href.match(ID_RE);
        if (m) { id = m[1]; url = new URL(href, location.origin).href; }
      }
      if (!id) {
        const m = (el.getAttribute('jslog') || '').match(/c_([a-f0-9]{8,})/i);
        if (m) id = m[1];
      }
      if (!id || seen.has(id)) continue;
      seen.add(id);
      const titleEl = el.querySelector('.conversation-title, [data-test-id="conversation-title"]');
      const title = ((titleEl ? titleEl.innerText : el.innerText) || '').trim().split('\n')[0].trim();
      out.push({ id, title, url: url || `${location.origin}/app/${id}`, el });
    }
    return out;
  }

  async function collectAll(onProgress) {
    let entries = convEntries();
    if (!entries.length) {
      const btn = document.querySelector('button[data-test-id="side-nav-menu-button"], button[aria-label*="main menu" i]');
      if (btn) { btn.click(); await sleep(1200); entries = convEntries(); }
    }
    if (!entries.length) {
      throw new Error('No chats found in the sidebar. Open the left sidebar so your chat list is visible, then try again.');
    }
    const map = new Map();
    const add = () => {
      for (const e of convEntries()) if (!map.has(e.id)) map.set(e.id, { id: e.id, title: e.title, url: e.url });
    };
    add();
    const scroller = scrollableAncestor(entries[entries.length - 1].el);
    let stable = 0, last = -1;
    for (let i = 0; i < 2000 && stable < 5; i++) {
      for (const b of document.querySelectorAll('button, [role="button"]')) {
        if (/^\s*show more\s*$/i.test(b.innerText || '') && !b.closest('model-response, user-query')) b.click();
      }
      const cur = convEntries();
      if (cur.length) cur[cur.length - 1].el.scrollIntoView({ block: 'end' });
      if (scroller) scroller.scrollTop = scroller.scrollHeight;
      await sleep(1000);
      add();
      if (onProgress) onProgress(map.size);
      stable = map.size === last ? stable + 1 : 0;
      last = map.size;
    }
    return [...map.values()];
  }

  // ---------------- Extraction ----------------
  // Every element that could be the chat's real scroll container: all scrollable
  // ancestors of the first message, plus Gemini's known containers.
  function historyScrollers() {
    const set = new Set();
    const first = document.querySelector(TURN_SEL);
    for (let p = first && first.parentElement; p && p !== document.documentElement; p = p.parentElement) {
      const oy = getComputedStyle(p).overflowY;
      if ((oy === 'auto' || oy === 'scroll' || oy === 'overlay') && p.scrollHeight > p.clientHeight + 5) set.add(p);
    }
    for (const el of document.querySelectorAll('infinite-scroller, #chat-history, .chat-history-scroll-container, [data-test-id="chat-history-container"]')) {
      if (el.scrollHeight > el.clientHeight + 5) set.add(el);
    }
    return [...set];
  }

  // Imitate a person scrolling up: move each container to the top, fire the
  // scroll and wheel events the page listens for, and bring the oldest loaded
  // message into view (which trips any "load more" sentinel above it).
  function nudgeToTop(jiggle) {
    const first = document.querySelector(TURN_SEL);
    for (const s of historyScrollers()) {
      if (jiggle) { s.scrollTop = Math.min(400, s.scrollHeight); s.dispatchEvent(new Event('scroll', { bubbles: true })); }
      s.scrollTop = 0;
      s.dispatchEvent(new Event('scroll', { bubbles: true }));
      s.dispatchEvent(new WheelEvent('wheel', { deltaY: -2000, bubbles: true, cancelable: true }));
    }
    if (first) {
      first.scrollIntoView({ block: 'start' });
      first.dispatchEvent(new WheelEvent('wheel', { deltaY: -2000, bubbles: true, cancelable: true }));
    }
  }

  async function loadFullHistory(onProgress) {
    if (!document.querySelector(TURN_SEL)) return;
    let misses = 0;
    for (let round = 0; round < 1000 && misses < 3; round++) {
      const before = document.querySelectorAll(TURN_SEL).length;
      const firstBefore = document.querySelector(TURN_SEL);
      nudgeToTop(misses > 0);
      // Wait up to ~3.5s for an older batch to arrive.
      const grew = await waitFor(() => {
        const nodes = document.querySelectorAll(TURN_SEL);
        return nodes.length > before || nodes[0] !== firstBefore;
      }, 3500, 200);
      if (grew) {
        misses = 0;
        await sleep(400);
        if (onProgress) onProgress(document.querySelectorAll(TURN_SEL).length);
      } else {
        misses++;
      }
    }
  }

  function userText(el) {
    const lines = el.querySelectorAll('.query-text-line');
    let text;
    if (lines.length) {
      text = [...lines].map((l) => l.textContent.replace(/\u00a0/g, ' ').trimEnd()).join('\n');
    } else {
      const q = el.querySelector('.query-text') || el;
      text = q.innerText || q.textContent || '';
    }
    return text.replace(/^\s*You said:?\s*/i, '').trim();
  }

  function userTurnMd(el) {
    const parts = [userText(el)];
    for (const img of el.querySelectorAll('img')) {
      if (img.width && img.width < 48) continue; // avatars / icons
      const src = img.getAttribute('src') || '';
      parts.push(/^https?:/i.test(src) ? `![${img.alt || 'uploaded image'}](${src})` : '*[image attachment — not exported]*');
    }
    for (const f of el.querySelectorAll('[data-test-id="file-name"], .file-name, .new-file-name')) {
      const n = f.textContent.trim();
      if (n) parts.push(`*[attached file: ${n}]*`);
    }
    return parts.filter(Boolean).join('\n\n');
  }

  function modelTurnMd(el) {
    const notThoughts = (n) => !n.closest('model-thoughts');
    const container =
      [...el.querySelectorAll('message-content .markdown, .markdown')].find(notThoughts) ||
      [...el.querySelectorAll('message-content')].find(notThoughts) || el;
    return globalThis.GeminiMD.toMarkdown(container) || '*[empty response]*';
  }

  async function extractConversation(meta) {
    if (!(await waitFor(() => document.querySelector(TURN_SEL), 20000))) {
      throw new Error('No messages appeared (chat empty or failed to load)');
    }
    const label = document.getElementById('gx-text') ? document.getElementById('gx-text').textContent : 'Exporting';
    await loadFullHistory((n) => overlay(`${label} — loading older messages (${n})…`));
    await waitQuiet(document.querySelector('chat-window') || document.body);
    const turns = [...document.querySelectorAll(TURN_SEL)];
    const firstUser = turns.find((t) => t.tagName.toLowerCase() === 'user-query');
    const title = (meta.title || (firstUser ? userText(firstUser).split('\n')[0].slice(0, 70) : '') || 'Untitled chat').trim();
    const id = idFromPath(location.pathname) || meta.id;
    const out = [
      '---',
      `title: ${JSON.stringify(title)}`,
      `url: ${location.href}`,
      `conversation_id: ${id}`,
      `exported: ${new Date().toISOString()}`,
      `turns: ${turns.length}`,
      '---',
      '',
      `# ${title}`,
      ''
    ];
    for (const t of turns) {
      if (t.tagName.toLowerCase() === 'user-query') out.push('## You', '', userTurnMd(t), '');
      else out.push('## Gemini', '', modelTurnMd(t), '');
    }
    return { title, md: out.join('\n').trimEnd() + '\n' };
  }

  // ---------------- Saving ----------------
  async function saveFile(path, content) {
    let r;
    try { r = await chrome.runtime.sendMessage({ type: 'download', filename: path, content }); }
    catch (e) { r = { ok: false, error: String(e) }; }
    if (r && r.ok) return;
    // Fallback (e.g. very large chat): plain browser download into Downloads.
    const url = URL.createObjectURL(new Blob([content], { type: 'text/markdown;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = path.split('/').pop();
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 15000);
  }

  // ---------------- Run loop ----------------
  const onConv = (item) => location.pathname.includes(item.id);

  async function openConversation(item, st) {
    if (onConv(item)) return 'ok';
    if (!st.reloadEach) {
      const entry = convEntries().find((e) => e.id === item.id);
      if (entry) {
        const oldFirst = document.querySelector(TURN_SEL);
        entry.el.click();
        if (await waitFor(() => onConv(item), 10000)) {
          await waitFor(() => !oldFirst || !oldFirst.isConnected, 8000);
          return 'ok';
        }
      }
    }
    if ((st.navAttempts || 0) >= 2) return 'fail';
    const fresh = await getState();
    if (!fresh || !fresh.running) return 'stopped';
    st.navAttempts = (st.navAttempts || 0) + 1;
    await setState(st);
    location.assign(item.url);
    return 'reloading';
  }

  async function runQueue() {
    if (running) return;
    running = true;
    try {
      let st = await getState();
      while (st && st.running && st.index < st.queue.length) {
        const item = st.queue[st.index];
        const n = st.index + 1;
        overlay(`Exporting ${n}/${st.queue.length}: ${item.title || item.id}`);
        const nav = await openConversation(item, st);
        if (nav === 'reloading') return; // resumes after the page reloads
        if (nav === 'stopped') { st.running = false; break; }
        if (nav === 'fail') {
          st.failed.push({ ...item, error: 'Could not open chat' });
        } else {
          try {
            const { title, md } = await extractConversation(item);
            const file = `${String(n).padStart(4, '0')} - ${safeName(title)}.md`;
            await saveFile(`${st.folder}/${file}`, md);
            st.done.push({ title, file, url: item.url });
          } catch (e) {
            st.failed.push({ ...item, error: String((e && e.message) || e) });
          }
        }
        const fresh = await getState();
        st.running = !!(fresh && fresh.running);
        st.index++;
        st.navAttempts = 0;
        await setState(st);
        if (st.running && st.index < st.queue.length) await sleep(st.delay);
      }
      if (st && st.index >= st.queue.length) await finish(st);
      else if (st) {
        await setState(st);
        overlay(`Stopped at ${st.index}/${st.queue.length} (${st.done.length} saved). Resume from the extension popup.`, true);
      }
    } finally {
      running = false;
    }
  }

  async function finish(st) {
    const esc = (s) => s.replace(/([[\]])/g, '\\$1');
    const lines = [
      '# Gemini export', '',
      `Exported ${new Date().toLocaleString()} — ${st.done.length} chats saved` +
        (st.failed.length ? `, ${st.failed.length} failed.` : '.'),
      '', '## Chats', ''
    ];
    st.done.forEach((d, i) => lines.push(`${i + 1}. [${esc(d.title)}](${encodeURI(d.file)})`));
    if (st.failed.length) {
      lines.push('', '## Failed', '');
      for (const f of st.failed) lines.push(`- [${esc(f.title || f.id)}](${f.url}) — ${f.error}`);
    }
    await saveFile(`${st.folder}/_index.md`, lines.join('\n') + '\n');
    st.running = false;
    st.finished = true;
    await setState(st);
    overlay(`Done: ${st.done.length} chats saved to Downloads/${st.folder}` +
      (st.failed.length ? ` (${st.failed.length} failed — see _index.md)` : ''), true);
  }

  async function startAll(settings) {
    if (running || scanning) return;
    scanning = true;
    try {
      overlay('Scanning your chat list…');
      let list;
      try {
        list = await collectAll((n) => overlay(`Scanning your chat list… ${n} found`));
      } catch (e) {
        overlay(e.message, true);
        return;
      }
      await setState({
        running: true, mode: 'all', queue: list, index: 0, done: [], failed: [],
        folder: safeName(settings.folder || 'Gemini Export', 60),
        delay: Math.max(0, +settings.delay || 1500),
        reloadEach: !!settings.reloadEach,
        navAttempts: 0, startedAt: new Date().toISOString()
      });
      overlay(`Found ${list.length} chats. Starting…`);
    } finally {
      scanning = false;
    }
    runQueue();
  }

  async function resume() {
    const st = await getState();
    if (!st || st.index >= st.queue.length) return;
    st.running = true;
    st.navAttempts = 0;
    await setState(st);
    runQueue();
  }

  async function stop() {
    const st = await getState();
    if (st) { st.running = false; await setState(st); }
    overlay('Stopping after the current chat…');
  }

  async function exportCurrent(settings) {
    const id = idFromPath(location.pathname);
    if (!id) return { ok: false, error: 'Open a chat first.' };
    overlay('Exporting this chat…');
    try {
      const entry = convEntries().find((x) => x.id === id);
      const { title, md } = await extractConversation({ id, title: entry && entry.title, url: location.href });
      await saveFile(`${safeName(settings.folder || 'Gemini Export', 60)}/${safeName(title)}.md`, md);
      overlay(`Saved "${title}"`, true);
      return { ok: true };
    } catch (e) {
      overlay('Export failed: ' + e.message, true);
      return { ok: false, error: e.message };
    }
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || !msg.cmd) return;
    if (msg.cmd === 'ping') sendResponse({ ok: true });
    else if (msg.cmd === 'exportAll') { startAll(msg.settings || {}); sendResponse({ ok: true }); }
    else if (msg.cmd === 'resume') { resume(); sendResponse({ ok: true }); }
    else if (msg.cmd === 'stop') { stop(); sendResponse({ ok: true }); }
    else if (msg.cmd === 'exportCurrent') { exportCurrent(msg.settings || {}).then(sendResponse); return true; }
  });

  // Resume an in-progress run after a full page reload.
  (async () => {
    const st = await getState();
    if (st && st.running && st.mode === 'all' && st.index < st.queue.length) {
      await waitFor(() => document.querySelector('user-query, model-response, rich-textarea, chat-window'), 30000);
      await sleep(1000);
      runQueue();
    }
  })();
})();
