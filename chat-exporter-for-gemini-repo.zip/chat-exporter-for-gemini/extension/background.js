// Saves files via the downloads API so they can go into a sub-folder of Downloads.
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === 'download') {
    const url = 'data:text/markdown;charset=utf-8,' + encodeURIComponent(msg.content);
    chrome.downloads.download(
      { url, filename: msg.filename, conflictAction: 'uniquify', saveAs: false },
      (id) => {
        if (chrome.runtime.lastError || id === undefined) {
          sendResponse({ ok: false, error: (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'download failed' });
        } else {
          sendResponse({ ok: true, id });
        }
      }
    );
    return true; // async response
  }
});
