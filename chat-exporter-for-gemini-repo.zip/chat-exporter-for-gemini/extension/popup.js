const $ = (id) => document.getElementById(id);
const today = new Date().toISOString().slice(0, 10);

function status(text) { $('status').textContent = text; }

async function loadSettings() {
  const { gx_settings: s = {} } = await chrome.storage.local.get('gx_settings');
  $('folder').value = s.folder || `Gemini Export ${today}`;
  $('delay').value = s.delay != null ? s.delay : 1500;
  $('reloadEach').checked = !!s.reloadEach;
}

function readSettings() {
  return { folder: $('folder').value.trim(), delay: +$('delay').value || 0, reloadEach: $('reloadEach').checked };
}

async function send(cmd) {
  const settings = readSettings();
  await chrome.storage.local.set({ gx_settings: settings });
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !tab.url.startsWith('https://gemini.google.com/')) {
    status('Open gemini.google.com in this tab first.');
    return;
  }
  try {
    const r = await chrome.tabs.sendMessage(tab.id, { cmd, settings });
    if (r && r.ok === false && r.error) status(r.error);
    else if (cmd === 'exportAll') status('Started — watch the box in the bottom-right of the Gemini page. You can close this popup.');
  } catch (e) {
    status('Refresh the Gemini tab (the exporter loads when the page loads), then try again.');
  }
}

function showState(st) {
  $('resume').style.display = 'none';
  if (!st || !st.queue) return;
  const total = st.queue.length;
  if (st.running) status(`Exporting ${Math.min(st.index + 1, total)}/${total}…  (${st.done.length} saved, ${st.failed.length} failed)`);
  else if (st.finished) status(`Last run finished: ${st.done.length} saved, ${st.failed.length} failed.`);
  else if (st.index < total) {
    status(`Stopped at ${st.index}/${total} (${st.done.length} saved).`);
    $('resume').style.display = 'block';
  }
}

$('all').onclick = () => send('exportAll');
$('current').onclick = () => send('exportCurrent');
$('resume').onclick = () => send('resume');
$('stop').onclick = () => send('stop');

chrome.storage.onChanged.addListener((changes) => { if (changes.gx_state) showState(changes.gx_state.newValue); });

loadSettings();
chrome.storage.local.get('gx_state').then(({ gx_state }) => showState(gx_state));
