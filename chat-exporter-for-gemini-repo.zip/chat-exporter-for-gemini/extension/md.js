// Minimal HTML -> Markdown converter tuned for Gemini's rendered responses.
// Never uses innerHTML (gemini.google.com enforces Trusted Types).
(function (root) {
  const SKIP_SEL = [
    'button', 'mat-icon', 'script', 'style', 'svg', 'noscript', 'template',
    '.cdk-visually-hidden', 'model-thoughts', '.code-block-decoration',
    'message-actions', '.response-footer', '.export-sheets-button-container'
  ].join(',');
  const BLOCK = new Set(['P', 'DIV', 'SECTION', 'ARTICLE', 'HEADER', 'FOOTER', 'MAIN',
    'FIGURE', 'FIGCAPTION', 'DETAILS', 'SUMMARY', 'ASIDE']);

  function tidy(s) {
    return s
      .split('\n').map((l) => (/^[ \t]+$/.test(l) ? '' : l)).join('\n')
      .replace(/\n{3,}/g, '\n\n')
      .replace(/^\n+|\s+$/g, '');
  }

  function wrap(text, mark) {
    if (!text.trim()) return text;
    const m = text.match(/^(\s*)([\s\S]*?)(\s*)$/);
    return m[1] + mark + m[2] + mark + m[3];
  }

  function fenceFor(text) {
    const runs = text.match(/`+/g) || [];
    const longest = runs.reduce((a, r) => Math.max(a, r.length), 0);
    return '`'.repeat(Math.max(3, longest + 1));
  }

  function mathTex(el) {
    if (el.hasAttribute && el.hasAttribute('data-math')) return el.getAttribute('data-math');
    if (el.classList && (el.classList.contains('katex') || el.classList.contains('katex-display'))) {
      const ann = el.querySelector('annotation[encoding="application/x-tex"]');
      if (ann) return ann.textContent;
    }
    return null;
  }

  function renderChildren(el, ctx) {
    let out = '';
    for (const c of el.childNodes) out += render(c, ctx);
    return out;
  }

  function renderList(el, ctx) {
    const ordered = el.tagName === 'OL';
    let n = parseInt(el.getAttribute('start') || '1', 10) || 1;
    const items = [];
    for (const li of el.children) {
      if (li.tagName !== 'LI') continue;
      const marker = ordered ? `${n++}.` : '-';
      const pad = ' '.repeat(marker.length + 1);
      const body = tidy(renderChildren(li, { ...ctx, depth: ctx.depth + 1 }));
      const lines = body.split('\n');
      items.push(marker + ' ' + lines[0] + (lines.length > 1
        ? '\n' + lines.slice(1).map((l) => (l ? pad + l : l)).join('\n') : ''));
    }
    return '\n\n' + items.join('\n') + '\n\n';
  }

  function renderTable(el, ctx) {
    const rows = [...el.querySelectorAll('tr')].map((tr) =>
      [...tr.children].filter((c) => c.tagName === 'TD' || c.tagName === 'TH')
        .map((c) => tidy(renderChildren(c, ctx)).replace(/\n+/g, ' ').replace(/\|/g, '\\|')));
    if (!rows.length) return '';
    const cols = Math.max(...rows.map((r) => r.length));
    const line = (r) => '| ' + Array.from({ length: cols }, (_, i) => r[i] || '').join(' | ') + ' |';
    const out = [line(rows[0]), '| ' + Array(cols).fill('---').join(' | ') + ' |', ...rows.slice(1).map(line)];
    return '\n\n' + out.join('\n') + '\n\n';
  }

  function render(node, ctx) {
    if (node.nodeType === 3) return node.nodeValue.replace(/\s+/g, ' ');
    if (node.nodeType !== 1) return '';
    const el = node;
    const tag = el.tagName;
    if (el.matches(SKIP_SEL)) return '';

    const tex = mathTex(el);
    if (tex != null) {
      const display = el.classList.contains('math-block') || el.classList.contains('katex-display') ||
        !!el.closest('.math-block, .katex-display');
      return display ? `\n\n$$\n${tex.trim()}\n$$\n\n` : `$${tex.trim()}$`;
    }

    switch (tag) {
      case 'H1': case 'H2': case 'H3': case 'H4': case 'H5': case 'H6':
        return `\n\n${'#'.repeat(+tag[1])} ${tidy(renderChildren(el, ctx)).replace(/\n+/g, ' ')}\n\n`;
      case 'P':
        return `\n\n${renderChildren(el, ctx).trim()}\n\n`;
      case 'BR':
        return '  \n';
      case 'HR':
        return '\n\n---\n\n';
      case 'STRONG': case 'B':
        return wrap(renderChildren(el, ctx), '**');
      case 'EM': case 'I':
        return wrap(renderChildren(el, ctx), '*');
      case 'S': case 'DEL': case 'STRIKE':
        return wrap(renderChildren(el, ctx), '~~');
      case 'CODE': {
        const t = el.textContent;
        return t.includes('`') ? '`` ' + t + ' ``' : '`' + t + '`';
      }
      case 'PRE': {
        const codeEl = el.querySelector('code') || el;
        let lang = '';
        const block = el.closest('code-block, .code-block');
        const deco = block && block.querySelector('.code-block-decoration');
        if (deco) lang = (deco.textContent || '').trim().split(/\s+/)[0] || '';
        if (!lang) {
          const m = (codeEl.className || '').match(/language-([\w+#-]+)/);
          if (m) lang = m[1];
        }
        const text = codeEl.textContent.replace(/\n$/, '');
        const fence = fenceFor(text);
        return `\n\n${fence}${lang.toLowerCase()}\n${text}\n${fence}\n\n`;
      }
      case 'A': {
        const text = renderChildren(el, ctx).trim();
        const href = el.getAttribute('href');
        if (!href || /^javascript:/i.test(href)) return text;
        let abs = href;
        try { abs = new URL(href, el.ownerDocument.baseURI).href; } catch (e) { /* keep raw */ }
        return text ? `[${text}](${abs})` : `<${abs}>`;
      }
      case 'IMG': {
        const src = el.getAttribute('src') || '';
        const alt = (el.getAttribute('alt') || 'image').replace(/[[\]]/g, '');
        return /^https?:/i.test(src) ? `![${alt}](${src})` : `*[${alt}]*`;
      }
      case 'UL': case 'OL':
        return renderList(el, ctx);
      case 'BLOCKQUOTE': {
        const inner = tidy(renderChildren(el, ctx));
        return '\n\n' + inner.split('\n').map((l) => (l ? '> ' + l : '>')).join('\n') + '\n\n';
      }
      case 'TABLE':
        return renderTable(el, ctx);
      default:
        if (BLOCK.has(tag)) return `\n\n${renderChildren(el, ctx).trim()}\n\n`;
        return renderChildren(el, ctx);
    }
  }

  root.GeminiMD = {
    toMarkdown(el) { return tidy(render(el, { depth: 0 })); }
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
