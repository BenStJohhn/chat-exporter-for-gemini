# Changelog

## 1.1.0 — 2026-10-13
- Loads the complete history of long conversations before saving: scrolls to the top the way a person would and waits for each older batch to load.
- Progress box shows how many messages have loaded.
- Renamed to "Chat Exporter for Gemini" and marked as unofficial.

## 1.0.0 — 2026-10-12
- First release: export all chats or the current chat to Markdown, with YAML front matter, an index file, resume after interruption, and an optional reload-per-chat mode.
