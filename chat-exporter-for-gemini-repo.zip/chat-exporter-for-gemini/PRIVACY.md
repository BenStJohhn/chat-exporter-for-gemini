# Privacy policy

**Chat Exporter for Gemini** does not collect, transmit, sell or share any data.

- **What it reads:** the content of Gemini conversations displayed in your own browser tab on `gemini.google.com`, only when you click an export button.
- **Where that goes:** straight into Markdown files saved to your computer's Downloads folder. Nothing is sent to the developer or any third party.
- **What it stores:** your export settings (folder name, delay) and the progress of an export run, in Chrome's local extension storage on your device, so an interrupted export can resume. This contains your list of chat titles and links. It never leaves your device, and you can clear it by removing the extension.
- **Network access:** the extension makes no network requests of its own.
- **Analytics and tracking:** none.

The source code is public in this repository so you can check all of the above.

Questions: please open an issue on this repository.

_Last updated: October 2026_
